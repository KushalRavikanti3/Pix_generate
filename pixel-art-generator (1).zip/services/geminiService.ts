
import { GoogleGenAI } from "@google/genai";

if (!process.env.API_KEY) {
    // In a real dev environment, you'd see a more helpful message or a fallback.
    // For this context, we throw an error to indicate a missing configuration.
    console.error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

/**
 * Generates pixel art using Imagen 3.
 * @param userPrompt The user's description of the desired image.
 * @returns A base64 encoded string of the generated PNG image.
 */
export const generatePixelArt = async (userPrompt: string): Promise<string> => {
    const fullPrompt = `Pixel art, 8-bit, retro video game style, sprite. ${userPrompt}`;

    try {
        const response = await ai.models.generateImages({
            model: 'imagen-3.0-generate-002',
            prompt: fullPrompt,
            config: {
                numberOfImages: 1,
                outputMimeType: 'image/png',
                aspectRatio: '1:1',
            },
        });

        if (!response.generatedImages || response.generatedImages.length === 0 || !response.generatedImages[0].image.imageBytes) {
            throw new Error("API did not return any images.");
        }

        const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
        return base64ImageBytes;
        
    } catch (error) {
        console.error("Error generating image with Gemini API:", error);
        if (error instanceof Error) {
            throw new Error(`Failed to generate image: ${error.message}`);
        }
        throw new Error("An unexpected error occurred while generating the image.");
    }
};
