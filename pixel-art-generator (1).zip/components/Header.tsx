
import React from 'react';

const PixelIcon = () => (
    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="inline-block mr-4">
        <path fillRule="evenodd" clipRule="evenodd" d="M4 4H8V8H4V4ZM10 4H14V8H10V4ZM16 4H20V8H16V4ZM4 10H8V14H4V10ZM10 10H14V14H10V10ZM16 10H20V14H16V10ZM4 16H8V20H4V16ZM10 16H14V20H10V16ZM16 16H20V20H16V16Z" fill="#F472B6"/>
    </svg>
);

export const Header: React.FC = () => {
    return (
        <header className="text-center border-b-4 border-pink-500 pb-4">
            <h1 className="text-4xl sm:text-5xl font-bold text-pink-400 tracking-wider flex items-center justify-center">
                <PixelIcon />
                Pixel Art Gen
            </h1>
            <p className="text-sm text-cyan-400 mt-2">Create 8-bit masterpieces with AI</p>
        </header>
    );
};
