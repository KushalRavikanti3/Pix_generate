
import React, { useState } from 'react';
import { Loader } from './Loader';

interface PromptFormProps {
    onGenerate: (prompt: string) => void;
    isLoading: boolean;
}

const MagicWandIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 h-5 w-5">
        <path d="M5 3v4"></path><path d="M19 17v4"></path><path d="M3 5h4"></path><path d="M17 19h4"></path><path d="M12 3v18"></path><path d="M8.5 8.5 3 14"></path><path d="M15.5 8.5 21 14"></path><path d="M21 3 3 21"></path>
    </svg>
);

export const PromptForm: React.FC<PromptFormProps> = ({ onGenerate, isLoading }) => {
    const [prompt, setPrompt] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onGenerate(prompt);
    };

    return (
        <form onSubmit={handleSubmit} className="w-full flex flex-col items-center gap-4 my-8">
            <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="e.g., a heroic knight with a glowing sword"
                className="w-full max-w-2xl p-4 bg-gray-800 border-2 border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-cyan-400 focus:border-cyan-400 transition duration-200 resize-none text-base h-28"
                disabled={isLoading}
                style={{ fontFamily: 'sans-serif' }}
            />
            <button
                type="submit"
                disabled={isLoading}
                className="flex items-center justify-center px-8 py-4 bg-pink-500 text-white font-bold rounded-md hover:bg-pink-600 disabled:bg-gray-500 disabled:cursor-not-allowed transition-all duration-200 ease-in-out transform hover:scale-105 text-lg"
            >
                {isLoading ? (
                    <>
                        <Loader />
                        Generating...
                    </>
                ) : (
                    <>
                        <MagicWandIcon />
                        Generate Pixel Art
                    </>
                )}
            </button>
        </form>
    );
};
